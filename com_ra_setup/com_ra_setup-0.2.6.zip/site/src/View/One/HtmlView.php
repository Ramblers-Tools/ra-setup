<?php

/**
 * @version    4.7.8
 * @package    com_ra_setup
 * @author     Charlie Bigley <webmaster@bigley.me.uk>
 * @copyright  2023 Charlie Bigley
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 *
 * 07/09/26 CB created
 */

namespace Ramblers\Component\Ra_setup\Site\View\One;

defined('_JEXEC') or die;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\User\CurrentUserInterface;
use \Ramblers\Component\Ra_setup\Site\Helper\SetupHelper;
use \Ramblers\Component\Ra_tools\Site\Helpers\ToolsHelper;

class HtmlView extends BaseHtmlView implements CurrentUserInterface {

    protected $app;
    protected $form;
    protected $setupHelper;
    protected $toolsHelper;
    

    public function display($tpl = null)
    {
        $this->app = Factory::getApplication();
        $app = Factory::getApplication();
        $this->user = $this->app->getSession()->get('user');
        //       var_dump($this->user);
        //      die('id=' . $this->user->id);
        $this->setupHelper = new SetupHelper;
        $this->toolsHelper = new ToolsHelper;

        $this->setupHelper = new SetupHelper;
        $this->setupHelper->assertCanRunWizard();
        $this->form = $this->get('Form');

        if (!$this->form) {
            throw new \RuntimeException('Unable to load the setup form.', 500);
        }

        $this->document->setTitle('RA Setup Step One');
        return parent::display($tpl);
    }

}

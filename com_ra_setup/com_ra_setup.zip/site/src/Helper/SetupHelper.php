<?php
defined('_JEXEC') or die;
namespace Ramblers\Component\Ra_setup\Site\Helper;

class SetupHelper
{
    public static function getGreeting()
    {
        return 'RA Setup initialised';
    }
}